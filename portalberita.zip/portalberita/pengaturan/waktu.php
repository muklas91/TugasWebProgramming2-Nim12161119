<?php
	date_default_timezone_set("Asia/Jakarta"); //menyesuaikan dengan waktu di jakarta
	$skrg=date("Y-m-d H:i:s"); //untuk menampilkan format waktu dalam contoh berikut 2015-10-10
	// 17:05:04
	$jam_skrg=date("H:i:s"); //format jam
	$tgl_skrg=date("Y-m-d"); //format tanggal
	$hari_skrg=date("l"); //format hari (L kecil)
	
?>